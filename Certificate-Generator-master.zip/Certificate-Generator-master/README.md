**Don't Forget to :star2: this repo**
# Certificate-Generator
This Code cn create bulk amount of certificates in a fraction of :hourglass_flowing_sand: ..
## Prep. To Generate Certificates :blue_book::pencil2:
- Just design your certificate
- Determine the coordinates for the name to be placed on the certificate
- Check Eveything
- Keep the TTF file in the same folder
- Keep .jpeg of certificate in the same folder
- keep the .xlsx file in the same fold
- Make Sure the .xlsx file has following column in exact same shape:
  - Name
# You are ready to run :heavy_check_mark:
+ Type the following command in Git Bash or CMD in the same folder:
  + **_python certs.py_**
  
# For Help
For more help, refer to my article on Dev.to
[Generate Certificates using Python](https://dev.to/mursalfk/generate-certificates-using-python-e74)

## Get in Touch :link:
* [Youtube](https://www.youtube.com/channel/UCpe8Kkw3fXTF0J19ZIazf_Q?view_as=subscriber)
* [Facebook](www.faceb)
* [LinkedIn](https://www.linkedin.com/in/mursalfurqan/)
* [Medium](https://medium.com/@mursalfurqan)
* [Dev.to](https://dev.to/mursalfk)
* [Visit my website](mursalfurqan.com)
